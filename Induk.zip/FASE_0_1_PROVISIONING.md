# Fase 0–1 — Provisioning Supabase + Auth Hook + Seed

Tujuan: dari project kosong → user bisa login dan JWT-nya membawa
`medping_pin` + `roles`, sehingga **backend** (`get_current_principal`) dan
**RLS** (`identity.current_pin()` / `has_role()`) berfungsi, lalu **frontend**
ikut melihat PIN. Ikuti **berurutan**.

---

## 0. Buat project Supabase
1. Buat project baru di https://supabase.com → catat **Project URL**, **anon key**, **service_role key**.
2. Database → **Connection string** (URI). Ini jadi `DATABASE_URL` backend.

## 1. Isi environment
**backend/.env** (salin dari `.env.example`):
```
DATABASE_URL=postgresql://postgres:PASSWORD@db.PROJECT.supabase.co:5432/postgres
SUPABASE_URL=https://PROJECT.supabase.co
SUPABASE_JWT_SECRET=<Settings > API > JWT Secret>   # WAJIB: backend verifikasi HS256
```
**apps/*/.env** (tiap app, salin dari `.env.example`):
```
VITE_API_BASE_URL=http://localhost:8000/api/v1
VITE_SUPABASE_URL=https://PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=<anon key>
VITE_COOKIE_DOMAIN=.nakesmart.com    # dev lokal boleh dikosongkan
```

## 2. Jalankan migrasi (SQL Editor, URUT)
Tempel & RUN satu per satu, sesuai urutan:
```
0001_identity.sql      -- schema identity, profiles/PIN, wallet, ledger, RLS helpers
0002_events.sql
0003_care.sql
0004_clinic.sql
0005_careers.sql
0006_auth_hook.sql     -- ⭐ trigger auto-PIN + custom_access_token_hook + grants
```
> `0006` membuat fungsi `public.custom_access_token_hook` tapi **belum aktif** —
> diaktifkan di langkah 3.

## 3. Aktifkan Custom Access Token Hook  ⭐ WAJIB
Dashboard → **Authentication → Hooks** → **Customize Access Token (JWT) Claims**:
- Enable, pilih **Postgres function**: `public.custom_access_token_hook`.
- Simpan.

> Tanpa langkah ini, JWT TIDAK punya `medping_pin`/`roles` top-level →
> backend balas **403** dan semua RLS balas NULL.

## 4. Buat user + seed peran
1. Authentication → **Users → Add user** (atau signup dari app). Buat 3 akun uji,
   samakan email dengan yang ada di `0007_seed_dev.sql`:
   - `founder@nakesmart.com`      → `superadmin`, `nakes`
   - `klinik.admin@nakesmart.com` → `faskes_admin`
   - `pasien@nakesmart.com`       → `pasien`
   > Saat user dibuat, trigger `handle_new_user` otomatis bikin profil+PIN+wallet (default `pasien`).
2. SQL Editor → RUN **`0007_seed_dev.sql`** (DEV ONLY) untuk meng-upgrade peran,
   sinkron metadata, dan menautkan `klinik.admin` ke faskes demo.
3. **Logout lalu login ulang** semua user → JWT baru memuat `medping_pin` + `roles`.

## 5. Jalankan & verifikasi
**Backend:**
```bash
cd backend && uvicorn app.main:app --reload --port 8000
# http://localhost:8000/health  -> {"status":"ok"}
```
**Frontend (mis. NakesCare):**
```bash
npm install          # dari root (workspaces)
npm run dev:care     # http://localhost:5174  -> login -> dashboard tampil PIN + roles
```

### Cek cepat (manual)
1. **JWT membawa klaim?** Ambil `access_token` dari sesi (DevTools → app),
   decode di jwt.io → harus ada `medping_pin` & `roles` di level atas.
2. **Backend mengenali principal?**
   ```bash
   curl -s http://localhost:8000/api/v1/me \
     -H "Authorization: Bearer <ACCESS_TOKEN>" -H "X-App-Context: care"
   # -> {"medping_pin":"PIN0000xxxx", "roles":[...], ...}
   ```
   Tanpa hook aktif → `403 no medping_pin claim` (artinya langkah 3 terlewat).
3. **RLS ter-scope?** (SQL Editor sebagai role `authenticated` via "Run as user"
   atau dari app): pasien hanya melihat `care.health_diary` miliknya;
   `klinik.admin` hanya melihat data `faskes_id` = klinik demo.

---

## Checklist
- [ ] env backend + 5 app terisi (termasuk **SUPABASE_JWT_SECRET**)
- [ ] migrasi 0001–0006 sukses, URUT
- [ ] Hook `custom_access_token_hook` **Enabled** di Dashboard
- [ ] 3 user dibuat, `0007_seed_dev.sql` dijalankan, login ulang
- [ ] `/api/v1/me` balas `medping_pin` + `roles`
- [ ] RLS ter-scope (pasien vs faskes_admin)

## Troubleshooting
| Gejala | Penyebab | Solusi |
|---|---|---|
| `/me` balas 403 | hook belum aktif / belum login ulang | aktifkan hook (langkah 3), logout-login |
| PIN kosong di frontend | metadata belum tercermin | jalankan `0007` lalu login ulang |
| RLS balas kosong semua | `medping_pin` NULL di JWT | sama seperti 403 di atas |
| `permission denied for schema identity` (saat login) | grant auth admin belum jalan | pastikan blok grant di `0006` ter-RUN |
